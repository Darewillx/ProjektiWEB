let suggestions = [
    "shtepi",
    "banes",
    "toka",
    "lokale",
    "shitje",
    "qera",
]