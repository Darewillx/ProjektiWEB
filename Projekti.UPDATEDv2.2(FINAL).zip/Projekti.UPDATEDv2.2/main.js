const searchWrapper = document.querySelector(".searchbari");
const inputBox = searchWrapper.querySelector("input");
const suggBox = searchWrapper.querySelector(".Menu");

inputBox.onkeyup = (e) => {
   let userData = e.target.value; //qfar shkruan useri ne search box
   let emptyArray = [];
   if(userData){
       emptyArray = suggestions.filter((data) => {
        return data.toLocaleLowerCase().startsWith(userData.toLocaleLowerCase());
       })
       emptyArray = emptyArray.map((data) => {
           return data = '<li>' + data + '</li>';
       });
       searchWrapper.classList.add("active"); //tregohet autocomplete box
       showSuggestions(emptyArray);
       let allList = suggBox.querySelectorAll("li");
       for (let i = 0; i < allList.length; i++) {
           allList[i].setAttribute("onclick", "select(this)");
       }
    }else{
        searchWrapper.classList.remove("active"); //mshef autocomplete box
   }
}

function select(element){
    let selectData = element.textContent;
    inputBox.value = selectData; 
    searchWrapper.classList.remove("active");
}

function showSuggestions(list){
    let listData;
    if(!list.length){
        userValue = inputBox.value;
        listData = '<li>' + userValue + '</li>';
    }else{
        listData = list.join('');
    }
    suggBox.innerHTML = listData;
}

function openPage(){
  var x = document.getElementById("searchi").value;

  if (x === "shtepi"){
    window.open("shtepite/shtepi.html");
  }

    if (x === "shtepite"){
    window.open("shtepite/shtepi.html");
  }

    if (x === "shpi"){
    window.open("shtepite/shtepi.html");
  }

    if (x === "banesa"){
    window.open("banesat/banesa.html");
  }

      if (x === "banesat"){
    window.open("banesat/banesa.html");
  }

      if (x === "banes"){
    window.open("banesat/banesa.html");
  }

    if (x === "toka"){
    window.open("tokat/toka.html");
  }

    if (x === "tokat"){
    window.open("tokat/toka.html");
  }  

    if (x === "toke"){
    window.open("tokat/toka.html");
  }

      if (x === "tok"){
    window.open("tokat/toka.html");
  }

    if (x === "lokal"){
    window.open("lokalet/lokale.html");
  }

     if (x === "lokale"){
    window.open("lokalet/lokale.html");
  } 

     if (x === "lokalet"){
    window.open("lokalet/lokale.html");
  } 

  if (x === "shtepia 1"){
    window.open("shtepite/postet/posti1/index.html");
  }

  if (x === "shtepia 2"){
    window.open("shtepite/postet/posti2/index.html");
  }

    if (x === "shtepia 3"){
    window.open("shtepite/postet/posti3/index.html");
  }

    if (x === "shtepia 4"){
    window.open("shtepite/postet/posti4/index.html");
  }


  if (x === "banesa 1"){
    window.open("banesat/postet/posti1/index.html");
  }

  if (x === "banesa 2"){
    window.open("banesat/postet/posti2/index.html");
  }

    if (x === "banesa 3"){
    window.open("banesat/postet/posti3/index.html");
  }

    if (x === "banesa 4"){
    window.open("banesat/postet/posti4/index.html");
  }


  if (x === "toka 1"){
    window.open("tokat/postet/posti1/index.html");
  }

  if (x === "toka 2"){
    window.open("tokat/postet/posti2/index.html");
  }

    if (x === "toka 3"){
    window.open("tokat/postet/posti3/index.html");
  }

    if (x === "toka 4"){
    window.open("tokat/postet/posti4/index.html");
  }


  if (x === "lokali 1"){
    window.open("lokalet/postet/posti1/index.html");
  }

  if (x === "lokali 2"){
    window.open("lokalet/postet/posti2/index.html");
  }

    if (x === "lokali 3"){
    window.open("lokalet/postet/posti3/index.html");
  }

    if (x === "lokali 4"){
    window.open("lokalet/postet/posti4/index.html");
  }

    if (x === "shtepia1"){
    window.open("shtepite/postet/posti1/index.html");
  }

  if (x === "shtepia2"){
    window.open("shtepite/postet/posti2/index.html");
  }

    if (x === "shtepia3"){
    window.open("shtepite/postet/posti3/index.html");
  }

    if (x === "shtepia4"){
    window.open("shtepite/postet/posti4/index.html");
  }


  if (x === "banesa1"){
    window.open("banesat/postet/posti1/index.html");
  }

  if (x === "banesa2"){
    window.open("banesat/postet/posti2/index.html");
  }

    if (x === "banesa3"){
    window.open("banesat/postet/posti3/index.html");
  }

    if (x === "banesa4"){
    window.open("banesat/postet/posti4/index.html");
  }


  if (x === "toka1"){
    window.open("tokat/postet/posti1/index.html");
  }

  if (x === "toka2"){
    window.open("tokat/postet/posti2/index.html");
  }

    if (x === "toka3"){
    window.open("tokat/postet/posti3/index.html");
  }

    if (x === "toka4"){
    window.open("tokat/postet/posti4/index.html");
  }


  if (x === "lokali1"){
    window.open("lokalet/postet/posti1/index.html");
  }

  if (x === "lokali2"){
    window.open("lokalet/postet/posti2/index.html");
  }

    if (x === "lokali3"){
    window.open("lokalet/postet/posti3/index.html");
  }

    if (x === "lokali4"){
    window.open("lokalet/postet/posti4/index.html");
  }

      if (x === "udr"){
    window.open("udr.html");
  }

        if (x === "info"){
    window.open("udr.html");
  }
}